# Examples

Keep this folder lightweight.

Good candidates to add over time:

- Known-good baseline screenshots per engine (WebKit/Blink)
- Golden-path step definitions (if you split steps into JSON)
- Notes on known engine quirks you’ve encountered
